

<html>


    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">

    <div class="container">
    <body>
    <h2 style="margin: 20px">{{ $user->first_name }} {{ $user->last_name }} 's Profile</h2>


        <div class="col-sm-8 blog-main" style="margin: 20px">
            <hr>

            <h4>Email: {{ $user->email }}</h4>
            <h4>First Name: {{ $user->first_name }}</h4>
            <h4>Last Name: {{ $user->last_name }}</h4>
            <br>
            <h4>Roles:</h4>
            <table>
                @foreach($user->roles as $role)
                    <tr>
                        <td>{{$role->title}}</td>
                    </tr>
                @endforeach
            </table>

            <br><br>
            <h4>Dates Attended: </h4>
            <br>

            {{--@foreach($user->roles() as $role)
            <h4>{{ $role->title }}</h4>
            @endforeach--}}

        <br>


        </div>
    </body>

    </div>
</html>
