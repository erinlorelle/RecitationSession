<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Major;

class MajorController extends Controller
{
    public function index(){

        $majors = Major::all();

        return view('majors.index', compact('majors'));
        //return view('layouts.master', compact('majors'));
    }
    
    public function add(){
        
        request()->validate([
            'abbr' => 'required|min:4|max:4',
            'name' => 'required|min:2',
            'description' => 'required|min:4'
        ]);
        
        $major = new Major();
        $major->abbr = request('abbr');
        $major->name = request('name');
        $major->description = request('description');
        $major->save();
        
        return redirect('/majors');
    }
    
    public function delete($id){
        
        Major::destroy($id);
        
        return redirect('/majors');
    }
    
    public function edit($id){
        
        $editMajor = Major::find($id);
        return view('majors.update', compact('editMajor'));
    }
    
    public function update($id){
    
        request()->validate([
            'abbr' => 'required|min:4|max:4',
            'name' => 'required|min:2',
            'description' => 'required|min:4'
        ]);
        
        $updMajor = Major::find($id);
    
        $updMajor->abbr = request('abbr');
        $updMajor->name = request('name');
        $updMajor->description = request('description');
        $updMajor->save();
        
        //Session::flash('message', 'Successfully updated role!');
        return redirect('/majors');
    }
    
}
