<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Role;

class RoleController extends Controller
{
    public function index(){
        
        $roles = Role::all();
        
        
        return view('roles.index', compact('roles'));
    }
    
    public function add(){
        
        request()->validate([
            'title' => 'required|min:2',
            'description' => 'required|min:4'
        ]);
        
        $role = new Role();
        $role->title = request('title');
        $role->description = request('description');
        $role->save();
        
        return redirect('/roles');
    }
    
    public function delete($id){
        
        Role::destroy($id);
        
        return redirect('/roles');
    }
    
    public function edit($id){
        
        $editRole = Role::find($id);
        return view('roles.update', compact('editRole'));
    }
    
    public function update($id){
    
        request()->validate([
            'title' => 'required|min:2',
            'description' => 'required|min:4'
        ]);
        
        $updRole = Role::find($id);
    
        $updRole->title = request('title');
        $updRole->description = request('description');
        $updRole->save();
    
        //Session::flash('message', 'Successfully updated role!');
        return redirect('/roles');
    }
}
