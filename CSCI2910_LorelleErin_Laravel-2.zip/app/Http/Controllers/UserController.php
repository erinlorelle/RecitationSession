<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;

class UserController extends Controller
{
    public function index(){

        $users = User::all();
        //return $users;

        return view('users.index', compact('users'));
    }
    
    public function add(){
        
        request()->validate([
            'first_name' => 'required|min:2',
            'last_name' => 'required|min:2',
            'email' => 'email|required|unique:users,email'
        ]);
        
        $user = new User();
        $user->first_name = request('first_name');
        $user->last_name = request('last_name');
        $user->email = request('email');
        
        $user->save();
    
        //$user->roles()->attach(Role::where('title', 'Student')->get());
    
        $role = request('title');
        $user->roles()->attach(Role::where('title', compact('role'))->get());
        
        
        return redirect('/users');
    }
    
    public function delete($id){
        
        User::destroy($id);
        
        return redirect('/users');
    }
    
    public function edit($id){
        
        $editUser = User::find($id);
        return view('users.update', compact('editUser'));
    }
    
    public function update($id){
    
        request()->validate([
            'first_name' => 'required|min:2',
            'last_name' => 'required|min:2',
            'email' => 'email|required'
        ]);
        
        $updUser = User::find($id);
    
        $updUser->first_name = request('first_name');
        $updUser->last_name = request('last_name');
        $updUser->email = request('email');
        $updUser->save();
    
        $roleU = request('title');
        $updUser->roles()->attach(Role::where('title', compact('roleU'))->get());
        
        //Session::flash('message', 'Successfully updated role!');
        return redirect('/users');
    }
    
    public function profile($id){
    
        $user = User::with('user_roles')->find($id);
        //$user = User::find($id);
        //$role = Role::with('users')->get();
        
        return view('/users.profile', compact('user'));
    }
}
