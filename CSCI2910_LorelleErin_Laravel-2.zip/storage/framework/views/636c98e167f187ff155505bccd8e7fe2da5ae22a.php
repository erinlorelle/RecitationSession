

<html>
<head>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">
    <div class="container">
<body>
<h2 style="margin: 20px">Major Reports: Courses </h2>


<div class="col-sm-8 blog-main" style="margin: 20px">
    <br>

    <?php $majors = App\Major::all(); ?>
    <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4><?php echo e($major->abbr); ?> <?php echo e($major->description); ?></h4>
        <table class="table" style="margin: 20px">
        <tr>
            <th>Course Abbr</th>
            <th>Course Description</th>
        </tr>
        <?php $__currentLoopData = $major->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($course->course_number); ?></td>
                <td> <?php echo e($course->course_name); ?></td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</body>



</div>
</html>
