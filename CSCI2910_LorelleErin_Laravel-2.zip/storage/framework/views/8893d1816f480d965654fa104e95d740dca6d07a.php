

<html>


    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">

    <div class="container">
    <body>
    <h2 style="margin: 20px"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> 's Profile</h2>


        <div class="col-sm-8 blog-main" style="margin: 20px">
            <hr>

            <h4>Email: <?php echo e($user->email); ?></h4>
            <h4>First Name: <?php echo e($user->first_name); ?></h4>
            <h4>Last Name: <?php echo e($user->last_name); ?></h4>
            <br>
            <h4>Roles:</h4>
            <table>
                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->title); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            <br><br>
            <h4>Dates Attended: </h4>
            <br>

            

        <br>


        </div>
    </body>

    </div>
</html>
