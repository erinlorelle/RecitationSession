

<html>
<head>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">
    <div class="container">
<body>
<h2 style="margin: 20px">User Reports: by Role </h2>

<div class="col-sm-8 blog-main" style="margin: 20px">

<br>
<h4>Admini</h4>
<table class="table" style="margin: 20px">
    <thead>
    <tr>
        <th>Admin First Name</th>
        <th>Admin Last Name</th>
    </tr>
    </thead>

    <?php $usera = App\User::whereHas('roles', function ($query){$query->where('title', 'Admin');})->get();?>
    <?php $__currentLoopData = $usera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($usera->first_name); ?></td><td> <?php echo e($usera->last_name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<br>

    <h4>Professors</h4>
    <table class="table" style="margin: 20px">
        <thead>
        <tr>
            <th>Professor First Name</th>
            <th>Professor Last Name</th>
        </tr>
        </thead>

        <?php $users = App\User::whereHas('roles', function ($query){$query->where('title', 'Professor');})->get();?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->first_name); ?></td><td> <?php echo e($user->last_name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <br>
    <h4>Students</h4>
    <table class="table" style="margin: 20px">
        <thead>
        <tr>
            <th>Student First Name</th>
            <th>Student Last Name</th>
        </tr>
        </thead>

        <?php $userst = App\User::whereHas('roles', function ($query){$query->where('title', 'Student');})->get();?>
        <?php $__currentLoopData = $userst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usert->first_name); ?></td><td> <?php echo e($usert->last_name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</body>



</div>
</html>
