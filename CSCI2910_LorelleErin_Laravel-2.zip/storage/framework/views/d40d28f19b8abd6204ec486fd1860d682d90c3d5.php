<?php $__env->startSection('content'); ?>

    <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <h2>Welcome</h2>
                    <p class="lead">This website allows viewers to access the Recitation Session database in a neat, easy to read organized format:</p>
                    <ul>
                        <li>Itemized list of Majors, Courses, Users, and Roles</li>
                        <li>Includes associations between fields at a quick glance</li>
                        <li>Additional reports allow more in-depth viewing</li>
                    </ul><br>
                    <p class="lead">Click on the navigation links up top to browse data.</p>
                    <ul>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>