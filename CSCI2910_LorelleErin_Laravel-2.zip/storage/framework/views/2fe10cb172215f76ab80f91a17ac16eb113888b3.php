

<html>


<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

<!-- Custom styles for this template -->
<link href="css/album.css" rel="stylesheet">

<div class="container">
    <body>
    <h2 style="margin: 20px"><?php echo e($course->course_number); ?> <?php echo e($course->course_name); ?></h2>

    </body>

</div>
</html>