

    <html>


        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

        <!-- Custom styles for this template -->
        <link href="css/album.css" rel="stylesheet">

    <div class="container">
        <body>
        <h2 style="margin: 20px">Edit <?php echo e($editUser->first_name); ?> <?php echo e($editUser->last_name); ?></h2>

        <div class="col-sm-8 blog-main" style="margin: 20px">
            <br>
            <h4>Make any necessary changes below</h4>

            <form method="POST" action="/users/<?php echo e($editUser->id); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                <input type="text" class="form-control" id="email" name="email" value="<?php echo e($editUser->email); ?>">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($editUser->first_name); ?>">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e($editUser->last_name); ?>">
                </div>

                <div class="form-group">
                    <select class="form-control" id="title" name="title">
                        <option value="Student">Student</option>
                        <option value="Professor">Professor</option>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br>
            </form>
        </div>
        </body>


    </div>
    </html>
