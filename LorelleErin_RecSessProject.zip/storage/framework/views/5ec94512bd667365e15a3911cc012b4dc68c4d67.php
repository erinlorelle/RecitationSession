<?php $__env->startSection('content'); ?>

    <html>
    <div class="container">

        <?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <body>
        <h2 style="margin: 20px">List of Courses</h2>
        <table class="table" style="margin: 20px">
            <thead>
            <tr>
                <th>Id</th>
                <th>Major Id</th>
                <th>Course Number</th>
                <th>Course Name</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><a href="courses/<?php echo e($course->id); ?>"><?php echo e($course->id); ?></a></td>
                    <td><a href="majors"><?php echo e($course->major_id); ?></td>
                    <td><?php echo e($course->course_number); ?></td>
                    <td><?php echo e($course->course_name); ?></td>
                    <td><a href="courses/edit/<?php echo e($course->id); ?>"><i class="fas fa-pencil-alt"></i></td>
                    <td><a href="courses/delete/<?php echo e($course->id); ?>"><i class="far fa-trash-alt"></i></a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>


        </body>

        <div class="col-sm-8 blog-main">
            <br>
            <h6>Click the "Update" links to attend a course or assign a teacher to a course</h6>
            <br>
            <h4>Add a Course</h4>

            <form method="POST" action="/courses">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <input type="text" class="form-control" id="course_number" name="course_number" placeholder="Course Number">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="course_name" name="course_name" placeholder="Course Name">
                </div>

                <div class="form-group">
                    <select class="form-control" id="major" name="major">
                        <?=$majors = App\Major::all()?>
                        <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($major->description); ?>"><?php echo e($major->description); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br>
            </form>

        </div>

    </div>
    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>