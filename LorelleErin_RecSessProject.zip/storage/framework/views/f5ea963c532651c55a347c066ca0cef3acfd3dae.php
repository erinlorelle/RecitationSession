

<html>
<head>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/album.css" rel="stylesheet">

    <div class="container">
<body>
<h2 style="margin: 20px">Edit <?php echo e($editCourse->course_number); ?> <?php echo e($editCourse->course_name); ?></h2>


<div class="col-sm-8 blog-main" style="margin: 20px">
    <br>
    <h4>Make any necessary changes below</h4>

    <form method="POST" action="/courses/<?php echo e($editCourse->id); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>


        <div class="form-group">
            <input type="text" class="form-control" id="course_number" name="course_number" value="<?php echo e($editCourse->course_number); ?>">
        </div>

        <div class="form-group">
            <input type="text" class="form-control" id="course_name" name="course_name" value="<?php echo e($editCourse->course_name); ?>">
        </div>

        <div class="form-group">
            <select class="form-control" id="major" name="major">
                <?=$majors = App\Major::all()?>
                <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($editCourse->major->description); ?>"><?php echo e($major->description); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <br>
        <hr>
        <h4>Assign a teacher to this course</h4>

        <select name="teacher">
            <?=$users = App\User::whereHas('roles', function ($query){$query->where('title', 'Professor');})->get();?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->first_name); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>
        <hr>
        <h4>Student attending this course</h4>

        <select name="student">
            <?=$userst = App\User::whereHas('roles', function ($query){$query->where('title', 'Student');})->get();?>
            <?php $__currentLoopData = $userst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($usert->first_name); ?>"><?php echo e($usert->first_name); ?> <?php echo e($usert->last_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>
        <label for="title">Date Attending</label>
        <div class="form-group">
            <input type="text" class="form-control" id="date" name="date" value="2018-04-19">
        </div>

        <br>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>



        <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br>
    </form>

</div>

</div>
</html>