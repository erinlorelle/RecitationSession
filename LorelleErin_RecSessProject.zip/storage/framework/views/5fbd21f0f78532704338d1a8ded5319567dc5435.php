<?php $__env->startSection('content'); ?>

<html>
<div class="container">

    <?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <body>
        <h2 style="margin: 20px">List of Majors</h2>
            <table class="table" style="margin: 20px">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Abbr</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>
                </thead>

                    <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($major->id); ?></td>
                    <td><?php echo e($major->abbr); ?></td>
                    <td><?php echo e($major->name); ?></td>
                    <td><?php echo e($major->description); ?></td>
                    <td><a href="majors/edit/<?php echo e($major->id); ?>"><i class="fas fa-pencil-alt"></i></td>
                    <td><a href="majors/delete/<?php echo e($major->id); ?>"><i class="far fa-trash-alt"></i></a></td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>

    </body>

    <div class="col-sm-8 blog-main">
        <br>
        <h4>Add a Major</h4>

        <form method="POST" action="/majors">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <input type="text" class="form-control" id="abbr" name="abbr" placeholder="Major Abbr">
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="name" name="name" placeholder="Major Name">
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="description" name="description" placeholder="Major Description">
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>

            <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
        </form>

    </div>

</div>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>