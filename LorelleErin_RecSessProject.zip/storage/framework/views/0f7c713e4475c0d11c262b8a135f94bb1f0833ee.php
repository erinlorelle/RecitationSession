<html>

    <body>
            <table class="table" style="margin-left: auto; margin-right: auto">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Abbr</th>
                        <th>Name</th>
                        <th>Description</th>
                    </tr>
                </thead>

                    <?php foreach ($majors as $major):?>

                <tr>
                    <td><?= $major->id ?></td>
                    <td><?= $major->abbr ?></td>
                    <td><?= $major->name ?></td>
                    <td><?= $major->description ?></td>
                </tr>
                    <?php endforeach;?>

            </table>


    </body>


</html>