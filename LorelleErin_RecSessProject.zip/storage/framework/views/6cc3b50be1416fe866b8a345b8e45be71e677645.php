<?php $__env->startSection('content'); ?>

    <html>
    <div class="container">

        <?php echo $__env->make('layouts.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <body>
        <h2 style="margin: 20px">List of Users</h2>
        <table class="table" style="margin: 20px">
            <thead>
            <tr>
                <th>Id</th>
                <th>Email</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><a href="users/<?php echo e($user->id); ?>"><?php echo e($user->id); ?></a></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->first_name); ?></td>
                    <td><?php echo e($user->last_name); ?></td>
                    <td><a href="users/edit/<?php echo e($user->id); ?>"><i class="fas fa-pencil-alt"></i></td>
                    <td><a href="users/delete/<?php echo e($user->id); ?>"><i class="far fa-trash-alt"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        </body>
        <?php echo e($users->links()); ?>


        <div class="col-sm-8 blog-main">
            <br>
            <h4>Add a User</h4>

            <form method="POST" action="/users">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <input type="text" class="form-control" id="email" name="email" placeholder="User Email">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="first_name" name="first_name" placeholder="User's First Name">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="last_name" name="last_name" placeholder="User's Last Name">
                </div>

                <div class="form-group">
                    <select class="form-control" id="title" name="title">
                        <option value="Student">Student</option>
                        <option value="Professor">Professor</option>
                    </select>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>



                <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <br>
            </form>

        </div>

    </div>
    </html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>