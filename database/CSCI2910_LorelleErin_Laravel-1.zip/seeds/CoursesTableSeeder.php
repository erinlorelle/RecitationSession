<?php
    /**
     * Created by PhpStorm.
     * User: Erin Lorelle
     * Date: 4/7/2018
     * Time: 3:25 PM
     */
    
use Illuminate\Database\Seeder;

class CoursesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->createCourse("1","1", "2910", "Server Side Web Programming");
        $this->createCourse("2","1", "2150", "Computer Organization");
        $this->createCourse("3","1", "1710", "Web Design and Development");
        $this->createCourse("4","1", "1900", "Math for Computer Science");
        
    }
    
    private function createCourse($id, $major_id, $course_number, $course_name){
        
        $data = new App\Course;
        $data->id = $id;                    // temporarily hardcoded
        $data->major_id = $major_id;
        $data->course_number = $course_number;
        $data->course_name = $course_name;
        $data->save();
        
    }
}
