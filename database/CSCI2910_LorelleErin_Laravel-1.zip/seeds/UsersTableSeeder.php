<?php
    /**
     * Created by PhpStorm.
     * User: Erin Lorelle
     * Date: 4/7/2018
     * Time: 3:25 PM
     */
    
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->createUser("1","DESJARDINSM@mail.etsu.edu", "Mathew", "Desjardins", "2");
        $this->createUser("2","zelc@etsu.edu", "Erin", "Lorelle", "3");
        $this->createUser("3","MCFLYM@.etsu.edu", "Marty", "McFly", "1");
        $this->createUser("4","BROWNE@.etsu.edu", "Doc", "Brown", "2");
        $this->createUser("5","BUNNYB@.etsu.edu", "Bugs", "Bunny", "1");
        $this->createUser("6","RABBITR@.etsu.edu", "Roger", "Rabbit", "1");
        $this->createUser("7","YANKOVIC@.etsu.edu", "Weird Al", "Yankovic", "2");
    }
    
    private function createUser($id, $email, $first_name, $last_name, $role_id){
        
        $data = new App\User;
        $data->id = $id;                    // temporarily hardcoded
        $data->email = $email;
        $data->first_name = $first_name;
        $data->last_name = $last_name;
        $data->role_id = $role_id;
        $data->save();
        
    }
    

}
